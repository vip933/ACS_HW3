import shape
from shape import *


# ----------------------------------------------


class Parallelepiped(Shape):
    def __init__(self):
        self.edgeA = 0
        self.edgeB = 0
        self.edgeC = 0
        self.density = 0.0

    def ReadStrArray(self, strArray, i):
        # должно быт как минимум четыре непрочитанных значения в массиве
        if i >= len(strArray) - 3:
            return 0
        self.edgeA = int(strArray[i])
        self.edgeB = int(strArray[i + 1])
        self.edgeC = int(strArray[i + 2])
        self.density = float(strArray[i + 3])
        i += 4
        # print("Parallelepiped: a = ", self.a, " b = ", self.b, " c = ", self.c, " density = ", self.density)
        return i

    def Print(self):
        print("Parallelepiped: a = ", self.edgeA, " b = ", self.edgeB, " c = ", self.edgeC,
              ", Square of surface = ", self.Square)
        pass

    def Write(self, ostream):
        ostream.write("Parallelepiped: a = {}  b = {} c = {} density = {}, Square of surface = {}".format \
                          (self.edgeA, self.edgeB, self.edgeC, self.density, self.Square()))
        pass

    def Square(self):
        return float(2 * self.edgeA * self.edgeB +
                     2 * self.edgeA * self.edgeC +
                     2 * self.edgeB * self.edgeC)
        pass

    @staticmethod
    def RandomParallelepiped():
        parallelepiped = Parallelepiped()
        parallelepiped.edgeA = random.randint(0, 200)
        parallelepiped.edgeB = random.randint(0, 200)
        parallelepiped.edgeC = random.randint(0, 200)
        parallelepiped.density = random.random() + random.randint(0, 9)
        return parallelepiped
