# ----------------------------------------------
import randomShape


class Container:
    def __init__(self):
        self.store = []

    def MakeRandomContainer(self, size: int):
        print("start of init of random figures")
        while len(self.store) < size:
            self.store.append(randomShape.RandomShape())
        print("end of init of random figures")
        pass

    def Print(self):
        print("Container is store", len(self.store), "shapes:")
        for shape in self.store:
            shape.Print()
        print("Average mean of all surface squares of all shapes  = ", self.AverageMean())
        pass

    def Write(self, ostream):
        ostream.write("Container is store {} shapes:\n".format(len(self.store)))
        for shape in self.store:
            shape.Write(ostream)
            ostream.write("\n")
        pass

    def AverageMean(self):
        sum = 0.0
        for shape in self.store:
            sum += shape.Square()
        return sum / len(self.store)

    def RearrangeContainer(self, average: float):
        copyArr = []
        for shape in self.store:
            if shape.Square() <= average:
                copyArr.append(shape)
        for shape in self.store:
            if shape.Square() > average:
                copyArr.append(shape)
        for i in range(len(self.store)):
            self.store[i] = copyArr[i]
        pass
