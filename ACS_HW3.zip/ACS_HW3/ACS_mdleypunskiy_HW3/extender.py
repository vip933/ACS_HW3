from shape import *
from ball import *
from parallelepiped import *
from tetrahedron import *

from container import *
from readStrArray import *
from randomShape import *
