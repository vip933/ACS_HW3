import random
from ball import *
from parallelepiped import *
from tetrahedron import *


def RandomShape():
    choose = random.randint(1, 3)
    if choose == 1:
        return Ball.RandomBall()
    elif choose == 2:
        return Parallelepiped.RandomParallelepiped()
    elif choose == 3:
        return Tetrahedron.RandomTetrahedron()
