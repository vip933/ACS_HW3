import math
from shape import *


# ----------------------------------------------
class Ball(Shape):
    def __init__(self):
        self.radius = 0
        self.density = 0.0

    def ReadStrArray(self, strArray, i):
        # должно быт как минимум два непрочитанных значения в массиве
        if i >= len(strArray) - 1:
            return 0
        self.radius = int(strArray[i])
        self.density = float(strArray[i + 1])
        i += 2
        # print("Ball: raduis = ", self.radius, " density = ", self.density)
        return i

    def Print(self):
        print("Ball: radius = ", self.radius, " density = ", self.density, ", Square of surface = ", self.Square)
        pass

    def Write(self, ostream):
        ostream.write("Ball: radius = {}  density = {}, Square of surface = {}".format \
                          (self.radius, self.density, self.Square()))
        pass

    def Square(self):
        return float(4 * math.pi * self.radius * self.radius)
        pass

    @staticmethod
    def RandomBall():
        ball = Ball()
        ball.radius = random.randint(0, 200)
        ball.density = random.random() + random.randint(0, 9)
        return ball
