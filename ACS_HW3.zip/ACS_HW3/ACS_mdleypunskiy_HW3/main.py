import sys
import time

from extender import *

# ----------------------------------------------
if __name__ == '__main__':
    if len(sys.argv) != 5:
        print("Incorrect command line! You must write: python main -f "
              + "<inputFileName> <outputFileName> <outputFileName2>")
        print("Or: python main -n <count> <outputFileName> <outputFileName2>")
        exit()
    size = 10000

    if sys.argv[1] == "-f":
        isFileInput = True
    elif sys.argv[1] == "-n":
        isFileInput = False
        size = int(sys.argv[2])
        if (size < 1) or (size > 10000):
            print("Incorrect number of figures!")
            print("Correct number: 1 < number < 10000")
            exit()
    else:
        print("Incorrect flag!")
        exit()

    startTime = time.time()
    print('==> Start')

    container = Container()
    if isFileInput:
        ifile = open(sys.argv[2])
        str = ifile.read()
        ifile.close()
        strArr = str.replace("\n", " ").split(" ")
        figNum = ReadStrArray(container, strArr)
    else:
        Container.MakeRandomContainer(container, int(sys.argv[2]))

    ofile = open(sys.argv[3], 'w')
    container.Write(ofile)
    ofile.close()

    ofile2 = open(sys.argv[4], 'w')
    average = container.AverageMean()
    container.RearrangeContainer(average)
    ofile2.write("Average mean of all surface squares of all shapes {}\n".format(average))
    container.Write(ofile2)
    ofile2.close()

    print('==> Finish')
    print("running time: {} ms".format((time.time() - startTime)*1000))
