import math
import shape
from shape import *

# ----------------------------------------------
class Tetrahedron(Shape):
    def __init__(self):
        self.edgeA = 0
        self.density = 0.0

    def ReadStrArray(self, strArray, i):
        # должно быт как минимум два непрочитанных значения в массиве
        if i >= len(strArray) - 1:
            return 0
        self.edgeA = int(strArray[i])
        self.density = float(strArray[i + 1])
        i += 2
        # print("Tetrahedron: a = ", self.edgeA, " density = ", self.density)
        return i

    def Print(self):
        print("Tetrahedron: a = ", self.edgeA, " density = ", self.density, ", Square of surface = ", self.Square)
        pass

    def Write(self, ostream):
        ostream.write("Tetrahedron: a = {}  density = {}, Square of surface = {}".format \
                          (self.edgeA, self.density, self.Square()))
        pass

    def Square(self):
        return float(self.edgeA*self.edgeA*math.sqrt(3))
        pass

    @staticmethod
    def RandomTetrahedron():
        tetrahedron = Tetrahedron()
        tetrahedron.edgeA = random.randint(0, 200)
        tetrahedron.density = random.random() + random.randint(0, 9)
        return tetrahedron
