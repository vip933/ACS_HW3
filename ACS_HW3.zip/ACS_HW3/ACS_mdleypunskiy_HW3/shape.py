# ----------------------------------------------
import random


class Shape:
    def ReadStrArray(self, strArray, i):
        pass

    def Print(self):
        pass

    def Write(self, ostream):
        pass

    def Square(self):
        pass
